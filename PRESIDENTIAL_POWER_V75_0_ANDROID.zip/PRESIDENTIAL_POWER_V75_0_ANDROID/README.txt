PRESIDENTIAL POWER V75.0 - ANDROID PACKAGE

This archive contains the web application packaged for building an Android APK with Capacitor.

Build in GitHub Actions:
1. Extract this ZIP into a GitHub repository (keep package.json at repository root).
2. Add the workflow file from .github/workflows/android-apk-v75.yml to the repository.
3. Push to the main branch or run the workflow manually.
4. Download the generated debug APK from the workflow Artifacts.

This archive is a build source package, not a compiled APK. V74.8 source remains untouched.
