PRESIDENTIAL POWER V75.0 - ANDROID TEST BUILD
Cette variante utilise un identifiant Android distinct pour être installée à côté de V74.8.
Elle ne remplace pas V74.8. Les deux applications restent séparées sur le téléphone.
La connexion au même compte Supabase peut permettre de récupérer la sauvegarde cloud ; vérifier les données affichées avant toute utilisation continue.
Application ID: com.presidentialpower.game.v750test
