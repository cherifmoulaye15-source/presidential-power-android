PRESIDENTIAL POWER V74.8 — PREPARATION ANDROID
================================================

CONTENU
- www/index.html : jeu HTML V74.8 (copie de travail)
- package.json : dépendances Capacitor 8
- capacitor.config.ts : identifiant et configuration de l'application

PROTECTION DES VERSIONS
- V73 de référence n'est pas modifiée.
- V74.7 n'est pas modifiée.
- Ce dossier est une copie de travail V74.8.

PREREQUIS POUR GENERER L'APPLICATION ANDROID
- Node.js 22 ou plus récent
- Android Studio récent
- Android SDK installé depuis Android Studio
- Connexion Internet pour installer les dépendances et synchroniser Capacitor

COMMANDES (dans le dossier du projet)
1. npm install
2. npx cap add android
3. npx cap sync android
4. npx cap open android

Dans Android Studio : tester sur un téléphone Android connecté ou un émulateur.
Pour préparer une publication, générer ensuite un Android App Bundle (AAB) signé.

IMPORTANT
Ce paquet est un projet de préparation Capacitor, pas encore un APK ou AAB.
La bibliothèque Supabase est actuellement chargée depuis jsDelivr et nécessite
une connexion Internet. Les fonctions d'authentification, sauvegarde, navigation,
liens externes et permissions doivent être testées dans l'application native.
Ne pas publier avant ces tests.
